const API_BASE_URL =
    "http://localhost:8080/api";

/*
    PAGE LOAD
*/

window.onload = function () {

    console.log("ADMIN PAGE LOADED");

    loadAdminDashboard();
};

/*
    LOAD ADMIN DASHBOARD
*/

async function loadAdminDashboard() {

    const token =
        localStorage.getItem("token");

    console.log("TOKEN:", token);

    if (!token) {

        alert("Please login first");

        window.location.href =
            "index.html";

        return;
    }

    try {

        /*
            SUMMARY API
        */

        console.log("LOADING SUMMARY...");

        const summaryResponse =
            await fetch(
                `${API_BASE_URL}/admin/stats/summary`,
                {
                    headers: {
                        Authorization:
                            `Bearer ${token}`
                    }
                }
            );

        console.log(
            "SUMMARY STATUS:",
            summaryResponse.status
        );

        /*
            HANDLE 403
        */

        if (summaryResponse.status === 403) {

            alert(
                "Access Denied! Admin login required."
            );

            localStorage.clear();

            window.location.href =
                "index.html";

            return;
        }

        /*
            HANDLE OTHER ERRORS
        */

        if (!summaryResponse.ok) {

            throw new Error(
                "Failed to load summary"
            );
        }

        /*
            SAFE JSON PARSE
        */

        const summaryText =
            await summaryResponse.text();

        console.log(
            "SUMMARY RESPONSE:",
            summaryText
        );

        let summary = {};

        if (summaryText) {

            summary =
                JSON.parse(summaryText);
        }

        /*
            SET SUMMARY VALUES
        */

        document.getElementById(
            "totalUsers"
        ).innerText =
            summary.totalUsers || 0;

        document.getElementById(
            "totalMedications"
        ).innerText =
            summary.totalMedications || 0;

        document.getElementById(
            "totalLogs"
        ).innerText =
            summary.totalReminderLogs || 0;

        /*
            LOAD USERS
        */

        await loadUsers();

        console.log(
            "ADMIN DASHBOARD LOADED"
        );

    }
    catch(error) {

        console.error(
            "DASHBOARD ERROR:",
            error
        );

        alert(
            "Error loading dashboard. Check console."
        );
    }
}

/*
    LOAD USERS
*/

async function loadUsers() {

    const token =
        localStorage.getItem("token");

    try {

        const response =
            await fetch(
                `${API_BASE_URL}/admin/users`,
                {
                    headers: {
                        Authorization:
                            `Bearer ${token}`
                    }
                }
            );

        if (!response.ok) {

            throw new Error(
                "Failed to load users"
            );
        }

        /*
            GET RAW RESPONSE
        */

        const responseText =
            await response.text();

        console.log(
            "RAW USERS RESPONSE:",
            responseText
        );

        /*
            SAFE JSON PARSE
        */

        let users = [];

        try {

            users =
                JSON.parse(responseText);

        }
        catch(error) {

            console.error(
                "INVALID JSON RESPONSE:",
                error
            );

            console.log(
                "ACTUAL RESPONSE:",
                responseText
            );

            alert(
                "Backend returned invalid JSON"
            );

            return;
        }

        console.log(
            "USERS:",
            users
        );

        const tbody =
            document.getElementById(
                "userTableBody"
            );

        tbody.innerHTML = "";

        /*
            NO USERS
        */

        if (users.length === 0) {

            tbody.innerHTML = `

                <tr>

                    <td colspan="7">
                        No users found
                    </td>

                </tr>
            `;

            return;
        }

        /*
            ADD USERS
        */

        users.forEach(user => {

            console.log(
                "USER:",
                user
            );

            const row =
                document.createElement("tr");

            row.innerHTML = `

                <td>${user.id || ""}</td>

                <td>${user.fullName || ""}</td>

                <td>${user.email || ""}</td>

                <td>${user.role || ""}</td>

                <td>${user.totalMedications || 0}</td>

                <td>${user.totalReminders || 0}</td>

                <td>

                    <button onclick="deleteUser(${user.id})">
                        Delete
                    </button>

                </td>
            `;

            tbody.appendChild(row);
        });

    }
    catch(error) {

        console.error(
            "LOAD USERS ERROR:",
            error
        );

        alert(
            "Error loading users"
        );
    }
}

/*
    CREATE ADMIN
*/

async function createAdmin() {

    const token =
        localStorage.getItem("token");

    const admin = {

        fullName:
            document.getElementById(
                "adminName"
            ).value.trim(),

        email:
            document.getElementById(
                "adminEmail"
            ).value.trim(),

        password:
            document.getElementById(
                "adminPassword"
            ).value.trim(),

        phone:
            document.getElementById(
                "adminPhone"
            ).value.trim(),

        timezone:
            "Asia/Kolkata"
    };

    /*
        VALIDATION
    */

    if (
        !admin.fullName ||
        !admin.email ||
        !admin.password ||
        !admin.phone
    ) {

        alert(
            "Please fill all fields"
        );

        return;
    }

    try {

        const response =
            await fetch(
                `${API_BASE_URL}/admin/create-admin`,
                {
                    method: "POST",

                    headers: {

                        "Content-Type":
                            "application/json",

                        Authorization:
                            `Bearer ${token}`
                    },

                    body:
                        JSON.stringify(admin)
                }
            );

        const text =
            await response.text();

        console.log(text);

        document.getElementById(
            "adminMessage"
        ).innerText = text;

        /*
            CLEAR INPUTS
        */

        document.getElementById(
            "adminName"
        ).value = "";

        document.getElementById(
            "adminEmail"
        ).value = "";

        document.getElementById(
            "adminPassword"
        ).value = "";

        document.getElementById(
            "adminPhone"
        ).value = "";

        loadAdminDashboard();

    }
    catch(error) {

        console.error(
            "CREATE ADMIN ERROR:",
            error
        );

        alert(
            "Failed to create admin"
        );
    }
}

/*
    DELETE USER
*/

async function deleteUser(id) {

    const token =
        localStorage.getItem("token");

    const confirmDelete =
        confirm(
            "Are you sure you want to delete this user?"
        );

    if (!confirmDelete) {

        return;
    }

    try {

        const response =
            await fetch(
                `${API_BASE_URL}/admin/users/${id}`,
                {
                    method: "DELETE",

                    headers: {
                        Authorization:
                            `Bearer ${token}`
                    }
                }
            );

        const text =
            await response.text();

        console.log(text);

        alert(text);

        loadAdminDashboard();

    }
    catch(error) {

        console.error(
            "DELETE USER ERROR:",
            error
        );

        alert(
            "Failed to delete user"
        );
    }
}

/*
    LOGOUT
*/

function logout() {

    localStorage.clear();

    window.location.href =
        "index.html";
}