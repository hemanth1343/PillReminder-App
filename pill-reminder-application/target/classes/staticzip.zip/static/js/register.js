async function registerUser() {

    const fullName = document.getElementById("fullName").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    const response = await fetch(
        "http://localhost:8080/api/auth/register",
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                fullName,
                email,
                password
            })
        }
    );

    if(response.ok) {

        alert("Registration Successful");

        window.location.href = "index.html";
    }
    else {
        alert("Registration Failed");
    }
}