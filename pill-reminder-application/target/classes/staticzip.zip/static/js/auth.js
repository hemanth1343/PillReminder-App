const BASE_URL =
    "http://localhost:8080/api";

/*
    LOGIN FUNCTION
*/

async function login() {

    console.log("LOGIN BUTTON CLICKED");

    const email =
        document.getElementById("email").value;

    const password =
        document.getElementById("password").value;

    /*
        VALIDATION
    */

    if (!email || !password) {

        alert("Please enter email and password");

        return;
    }

    try {

        /*
            LOGIN API CALL
        */

        const response = await fetch(
            `${BASE_URL}/auth/login`,
            {
                method: "POST",

                headers: {
                    "Content-Type":
                        "application/json"
                },

                body: JSON.stringify({
                    email,
                    password
                })
            }
        );

        console.log(
            "LOGIN STATUS => ",
            response.status
        );

        /*
            INVALID LOGIN
        */

        if (!response.ok) {

            alert(
                "Invalid email or password"
            );

            return;
        }

        /*
            RESPONSE DATA
        */

        const data =
            await response.json();

        console.log(
            "LOGIN RESPONSE => ",
            data
        );

        /*
            ACCESS TOKEN
        */

        const token =
            data.accessToken;

        if (!token) {

            alert(
                "Access token missing"
            );

            return;
        }

        /*
            SAVE TOKEN
        */

        localStorage.setItem(
            "token",
            token
        );

        console.log(
            "TOKEN SAVED"
        );

        /*
            GET ROLE
        */

        const role =
            data.user.role;

        console.log(
            "ROLE => ",
            role
        );

        /*
            REDIRECT
        */

        if (
            role === "ROLE_ADMIN" ||
            role === "ROLE_SUPER_ADMIN"
        ) {

            console.log(
                "Redirecting to admin"
            );

            window.location.href =
                "admin.html";
        }
        else {

            console.log(
                "Redirecting to medications"
            );

            window.location.href =
                "medications.html";
        }

    }
    catch(error) {

        console.log(
            "LOGIN ERROR => ",
            error
        );

        alert(
            "Server error"
        );
    }
}