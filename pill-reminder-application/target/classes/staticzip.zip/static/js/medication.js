async function loadMedications() {

    const token =
        localStorage.getItem("token");

    try {

        const response = await fetch(
            "/api/medications",
            {
                method: "GET",

                headers: {
                    "Content-Type": "application/json",

                    "Authorization":
                        `Bearer ${token}`
                }
            }
        );

        console.log(response);

        // SAFELY HANDLE EMPTY RESPONSE
        let data = [];

        try {

            data =
                await response.json();

        }
        catch(e) {

            console.log("No JSON Response");
        }

        console.log(data);

        const list =
            document.getElementById("list");

        list.innerHTML = "";

        // CHECK ARRAY
        if(!Array.isArray(data)) {

            list.innerHTML =
                "<li>No Medications Found</li>";

            return;
        }

        // EMPTY
        if(data.length === 0) {

            list.innerHTML =
                "<li>No Medications Found</li>";

            return;
        }

        // DISPLAY
        data.forEach(medication => {

            list.innerHTML += `

                <li class="card">

                    <h3>
                        ${medication.name || ""}
                    </h3>

                    <p>
                        Dosage :
                        ${medication.dosage || ""}
                    </p>

                    <p>
                        Frequency :
                        ${medication.frequency || ""}
                    </p>

                </li>
            `;
        });

    }
    catch(error) {

        console.log(error);

        alert("Server Error");
    }
}


async function addMedication() {

    const token =
        localStorage.getItem("token");

    // INPUT VALUES
    const name =
        document.getElementById("name").value;

    const dosage =
        document.getElementById("dosage").value;

    const quantity =
        document.getElementById("quantity").value;

    const refillThreshold =
        document.getElementById("refillThreshold").value;

    const instructions =
        document.getElementById("instructions").value;

    const frequency =
        document.getElementById("frequency").value;

    const startDate =
        document.getElementById("startDate").value;

    const scheduledTimes =
        document.getElementById("scheduledTimes").value;

    // VALIDATION
    if(
        name === "" ||
        dosage === "" ||
        frequency === "" ||
        startDate === "" ||
        scheduledTimes === ""
    ) {

        alert("Please Fill All Required Fields");

        return;
    }

    // PAYLOAD
    const payload = {

        name: name,

        dosage: dosage,

        quantity:
            quantity === ""
                ? 0
                : parseInt(quantity),

        refillThreshold:
            refillThreshold === ""
                ? 0
                : parseInt(refillThreshold),

        instructions: instructions,

        frequency: frequency,

        startDate: startDate,

        scheduledTimes:
            scheduledTimes
                .split(",")
                .map(time => time.trim())
    };

    console.log(payload);

    try {

        const response = await fetch(
            "http://localhost:8080/api/medications",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json",

                    "Authorization":
                        `Bearer ${token}`
                },

                body: JSON.stringify(payload)
            }
        );

        console.log(response);

        let data = {};

        try {

            data =
                await response.json();

        }
        catch(e) {

            console.log("No JSON Response");
        }

        console.log(data);

		if(response.ok) {

		    alert("Medication Added Successfully");

		    // CLEAR FORM
		    document.getElementById("name").value = "";

		    document.getElementById("dosage").value = "";

		    document.getElementById("quantity").value = "";

		    document.getElementById("refillThreshold").value = "";

		    document.getElementById("instructions").value = "";
			
			document.getElementById("frequency").value = "";

		    document.getElementById("startDate").value = "";

		    document.getElementById("scheduledTimes").value = "";

		    // RELOAD LIST
		    loadMedications();
			console.log(data);
		    return;
		}
        else {

            alert(
                data.message ||
                JSON.stringify(data) ||
                "Failed To Add Medication"
            );
        }

    }
    catch(error) {

        console.log(error);

        alert("Server Error");
    }
}